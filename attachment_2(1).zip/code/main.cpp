#include <chrono>
#include <cstdio>
#include <string>

#include <omp.h>

#include "wavefront.h"


using std::printf;
using std::scanf;
using std::chrono::steady_clock;
using std::micro;
using std::stoi;

const int C4 = 4;
const int C5 = 5;

void time4(double* data, int nx, int ny, int Nx);
void time5(double* data, int nx, int ny, int Nx, int Ny);

int main(int argc, char* argv[]) {
    // Parse arguments
    if (argc < 3 ) {
        printf("Not enough arguments supplied; exiting program...\n");
        return -1;
    } 
    
    int choice = stoi(argv[1], NULL);
    int Nx = 0;
    int Ny = 0;
    if (argc == 3 && choice == C4) {
        Nx = stoi(argv[2], NULL);
    } else if (argc == 4 && choice == C5) {
        Nx = stoi(argv[2], NULL);
        Ny = stoi(argv[3], NULL);
    } else {
        printf("Incorrect number of arguments supplied for option %d; exiting program...\n", choice);
        return -1;
    }

    // Allocate memory
    double* data = NULL;
    data = new double[(ny+1)*(nx+1)];
    if (data == NULL) {
        printf("Could not allocate enough memory for data; exiting program... \n");
        return -2;
    }

    // Call the appropriate timing function
    if (choice == C4)
        time4(data, nx, ny, Nx);
    else if (choice == C5)
        time5(data, nx, ny, Nx, Ny);
    else {
        printf("Invalid choice entered; exiting program...\n");
        return -3;
    }

    return 0;
}


void time4(double* data, int nx, int ny, int Nx) {
    steady_clock::time_point start = steady_clock::now();
    wavefront4(data, nx, ny, Nx);
    steady_clock::time_point end = steady_clock::now();
    auto diff = end - start;

    printf("Total time (4): \n    Nx = %d\n    T (microseconds): %.5lf\n", Nx, 
        std::chrono::duration<double, micro>(diff).count() );
}


void time5(double* data, int nx, int ny, int Nx, int Ny) {
    steady_clock::time_point start = steady_clock::now();
    wavefront4(data, nx, ny, Nx);
    steady_clock::time_point end = steady_clock::now();
    auto diff = end - start;

    printf("Total time (5): \n    Nx = %d, Ny = %d\n    T (microseconds): %.4lf\n", Nx, Ny,
        std::chrono::duration<double, micro>(diff).count() );

}